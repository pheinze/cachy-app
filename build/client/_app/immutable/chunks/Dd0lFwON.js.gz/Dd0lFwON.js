const e=`*feedback@cachy.app*

bc1qgrm2kvs27rfkpwtgp5u7w0rlzkgwrxqtls2q4f

***

# Changelog

### Inhaltsverzeichnis
1.  [Version 0.92b1](#v0.92b1)
2.  [Version 0.92b](#v0.92b)

---

## <a name="v0.92b1"></a>Version 0.92b1 (04. September 2025)
- **Neu:** Automatischer ATR-Abruf von der Binance-API mit wählbarem Zeitrahmen (5m, 15m, 1h, 4h, 1d). Der abgerufene Wert kann manuell angepasst werden.
- **Neu:** Erweiterte Sperr-Funktionen: Der Risikobetrag in Währung kann jetzt gesperrt werden, um die Positionsgröße und das Risiko in % zu berechnen.
- **Neu:** Tastaturkürzel (\`Alt+L/S/R/J\`) für schnellere Bedienung hinzugefügt.
- **Neu:** Modalfenster können jetzt mit der \`Escape\`-Taste oder per Klick auf den Hintergrund geschlossen werden.

---

## <a name="v0.92b"></a>Version 0.92b (22. August 2025)
- **Verbesserung:** Eingabefeld für Symbol akzeptiert jetzt Buchstaben und Zahlen.
- **Behoben:** Rand der Tooltips ist jetzt themenabhängig und das Problem des doppelten Randes wurde behoben.
- **Verbesserung:** Buttons "Trade zum Journal hinzufügen" und "Anleitung anzeigen" sind jetzt themenabhängig.
`;export{e as default};
